﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prakt_11_1_Sagutdinova
{
    internal class Student
    {
        public string name;
        public int rost;
        private double ves;
        public int eda;
        public double GetEat (double vs)
        {
            ves = vs;
            if (eda > 5 && eda < 10)
                ves += eda * 0.7;
            else if (eda > 10)
                ves += eda * 0.5;
            else
                ves = ves - 0;
            return ves;
        }
        public int SetEat(int vs)
        {
            rost = vs;
            if (eda > 5 && eda < 10)
                rost--;
            else if (eda > 10)
                rost = rost - 2;
            else
                rost = rost - 0;
            return rost;
        }
    }
}
