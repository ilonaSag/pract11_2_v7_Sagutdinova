﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prakt_11_1_Sagutdinova
{
    public partial class Student_work : Form
    {
        public Student_work()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Student student1 = new Student();
            student1.name = textBox1.Text;
            student1.rost = (int)numericUpDown1.Value;
            student1.eda = (int)numericUpDown3.Value;
            MessageBox.Show(string.Format("Студент: {0} \nрост {1} \nвес {2}", student1.name, student1.SetEat((int)numericUpDown1.Value), student1.GetEat((double)numericUpDown2.Value)));
        }
    }
}
